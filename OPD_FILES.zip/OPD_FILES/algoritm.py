import os
import json
from itertools import product
from collections import defaultdict

output_file_name = 'schedules' #название итогового файла
input_folder_name = 'input_schedules' #название папки с json файлами всех предметов
ogr = 300 #ограничение расписаний

f_terminal = False #переключение вывода расписаний в терминал (False, чтобы выключить)

def parse_time(time_str):
    """Парсит строку времени в формате 'HH:MM–HH:MM' в кортеж (часы, минуты) начала и конца"""
    time_part = time_str.split()[-1]  # Берем последнюю часть (время)
    start_end = time_part.split('–')
    start = tuple(map(int, start_end[0].split(':')))
    end = tuple(map(int, start_end[1].split(':')))
    return start, end


def check_time_overlap(lesson1, lesson2):
    """Проверяет, пересекаются ли два занятия по времени и дню"""
    if lesson1['день'] != lesson2['день']:
        return False
    
    try:
        start1, end1 = parse_time(lesson1['Место и время'])
        start2, end2 = parse_time(lesson2['Место и время'])
    except (IndexError, ValueError):
        # Если не удалось распарсить время, считаем что занятия пересекаются
        return True
    
    # Преобразуем время в минуты для удобства сравнения
    start1_min = start1[0] * 60 + start1[1]
    end1_min = end1[0] * 60 + end1[1]
    start2_min = start2[0] * 60 + start2[1]
    end2_min = end2[0] * 60 + end2[1]
    
    # Проверяем пересечение временных интервалов
    return not (end1_min <= start2_min or end2_min <= start1_min)


def group_lessons_by_team(data):
    """Группирует занятия по предметам и группам"""
    subjects = defaultdict(lambda: defaultdict(list))
    
    for lesson in data:
        subject = lesson['предмет']
        team = lesson['команда']
        subjects[subject][team].append(lesson)
    
    return subjects


def validate_team_schedule(lessons):
    """Проверяет, что все занятия одной группы не пересекаются"""
    for i in range(len(lessons)):
        for j in range(i + 1, len(lessons)):
            if check_time_overlap(lessons[i], lessons[j]):
                return False
    return True


def generate_schedules(subject_teams):
    """Генерирует все возможные непересекающиеся расписания"""
    if not subject_teams:
        return []
    
    # Получаем список предметов
    subjects = list(subject_teams.keys())
    
    # Для каждого предмета получаем список групп с валидными расписаниями
    valid_teams_per_subject = {}
    
    for subject in subjects:
        valid_teams = []
        for team, lessons in subject_teams[subject].items():
            if validate_team_schedule(lessons):
                valid_teams.append((team, lessons))
        valid_teams_per_subject[subject] = valid_teams
    
    # Генерируем все возможные комбинации групп (декартово произведение)
    all_combinations = product(*[valid_teams_per_subject[subject] for subject in subjects])
    
    valid_schedules = []
    
    for combination in all_combinations:
        all_lessons = []
        for team_lessons in combination:
            all_lessons.extend(team_lessons[1])  # team_lessons[1] - список занятий группы
        
        # Проверяем все пары занятий в комбинации на пересечение
        is_valid = True
        for i in range(len(all_lessons)):
            for j in range(i + 1, len(all_lessons)):
                if check_time_overlap(all_lessons[i], all_lessons[j]):
                    is_valid = False
                    break
            if not is_valid:
                break
        
        if is_valid:
            # Сохраняем информацию о предметах и группах
            schedule_info = []
            for subject, (team, lessons) in zip(subjects, combination):
                schedule_info.append((subject, team))
            valid_schedules.append((schedule_info, all_lessons))
    
    return valid_schedules


def format_schedule(schedule_info):
    """Форматирует расписание в читаемый вид"""
    return ", ".join(f"{subject} - {team}" for subject, team in schedule_info)


def print_schedule_statistics(subject_teams, valid_schedules):
    """Выводит статистику по расписаниям"""
    if not subject_teams:
        print("Нет данных для анализа")
        return
    
    # 1. Количество предметов
    num_subjects = len(subject_teams)
    
    # 2. Количество групп в сумме по всем предметам
    total_teams = sum(len(teams) for teams in subject_teams.values())
    
    # 3. Количество возможных расписаний вообще (все комбинации групп)
    total_possible_schedules = 1
    for teams in subject_teams.values():
        total_possible_schedules *= len(teams) if teams else 1
    
    # 4. Количество валидных расписаний
    num_valid_schedules = len(valid_schedules)
    
    # 5. Количество отброшенных расписаний
    num_rejected_schedules = total_possible_schedules - num_valid_schedules
    
    print("\nСтатистика расписаний:")
    print(f"1. Количество предметов: {num_subjects}")
    print(f"2. Всего групп: {total_teams}")
    print(f"3. Всего возможных комбинаций: {total_possible_schedules}")
    print(f"4. Валидных расписаний: {num_valid_schedules}")
    print(f"5. Отброшенных расписаний: {num_rejected_schedules}")
    
    # Дополнительная статистика по причинам отбраковки
    if total_possible_schedules > 0:
        rejection_percentage = (num_rejected_schedules / total_possible_schedules) * 100
        print(f"   Процент отбраковки: {rejection_percentage:.2f}%")

def save_schedules_to_json(valid_schedules, output_file=f"{output_file_name}.json", max_schedules=ogr):
    # Берем только первые max_schedules расписаний
    schedules_to_save = valid_schedules[:max_schedules]
    output_data = []

    for i, (schedule_info, all_lessons) in enumerate(schedules_to_save, 1):
        schedule_data = {
            "id_расписания": i,
            "предметы": []
        }

        # Группируем занятия по предметам и группам
        subject_lessons = defaultdict(list)
        for lesson in all_lessons:
            key = (lesson['предмет'], lesson['команда'])
            subject_lessons[key].append(lesson)

        # Формируем данные по каждому предмету
        for (subject, team), lessons in subject_lessons.items():
            subject_data = {
                "название_предмета": subject,
                "группа": team,
                "занятия": []
            }

            for lesson in lessons:
                # Разделяем место и время
                location_parts = lesson['Место и время'].rsplit(' ', 1)
                location = location_parts[0] if len(location_parts) > 1 else lesson['Место и время']
                time = location_parts[-1] if len(location_parts) > 1 else ""

                lesson_data = {
                    "тип_занятия": lesson['тип занятия'],
                    "день": lesson['день'],
                    "время": time,
                    "преподаватели": lesson['преподаватели'],
                    "аудитория": location
                }
                subject_data["занятия"].append(lesson_data)

            schedule_data["предметы"].append(subject_data)

        output_data.append(schedule_data)

    # Сохраняем в файл
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, ensure_ascii=False, indent=4, sort_keys=False)

    print(f"\nСохранено {len(schedules_to_save)} расписаний (первые {max_schedules} из {len(valid_schedules)}) в файл {output_file}")

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    json_folder = os.path.join(script_dir, input_folder_name)
    
    subject_teams = defaultdict(lambda: defaultdict(list))
    
    # Читаем все JSON-файлы и собираем данные по предметам и группам
    for filename in os.listdir(json_folder):
        if filename.endswith(".json"):
            json_file = os.path.join(json_folder, filename)
            
            print(f"Обработка файла: {json_file}")
            
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                subject_name = os.path.splitext(filename)[0]
                
                # Группируем занятия по группам
                for lesson in data:
                    team = lesson['команда']
                    subject_teams[subject_name][team].append(lesson)
    
    # Генерируем все возможные расписания
    schedules = generate_schedules(subject_teams)
    
    # Выводим результаты
    if not schedules:
        print("Не удалось найти ни одного непересекающегося расписания.")
    else:
        if f_terminal:
            print(f"\nНайдено {len(schedules)} возможных расписаний:\n")
            for i, (schedule_info, _) in enumerate(schedules, 1):
                print(f"Расписание {i}: {format_schedule(schedule_info)}")
               
        print_schedule_statistics(subject_teams, schedules)
        print()
        print('Создаю json-файл...')
        save_schedules_to_json(schedules)


if __name__ == "__main__":
    main()