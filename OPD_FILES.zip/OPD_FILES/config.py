YANDEX_GPT_API_KEY = "AQVNx-YnmWEsg125JKX_UZjzdQomhsRhtywl0NjF"
YANDEX_GPT_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"