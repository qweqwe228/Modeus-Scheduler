import requests
import json
from config import YANDEX_GPT_API_KEY, YANDEX_GPT_URL
from datetime import datetime
import re

# Конфигурация файлов
SCHEDULES_FILE = "schedules.json"
FILTERS_FILE = "schedule_filters.json"
RESULTS_FILE = "matched_schedules.json"

PROMPT_TEMPLATE = """Ты — помощник по составлению расписания. На основе пожеланий пользователя сформируй JSON с фильтрами.

Важно:
1. Все предметы обязательные - НЕ фильтруем по названиям предметов.
2. Работаем только с параметрами расписания и преподавателями.
3. Ответ должен содержать ТОЛЬКО валидный JSON.
4. Не добавляй фильтры, которые не указаны в запросе пользователя (например, если пользователь не просил ограничить корпус — не включай building_restrictions).
5. Не добавляй в фильтры то, что указано в скобочках, если этого не указывал пользователь. Когда я описываю доступные фильтры в скобках указываю примеры, чтобы тебе было проще понимать
6. Если пользователь указывает предмет с преподавателем - используй ТОЛЬКО фильтр preferred_teachers
7. Никогда не используй teacher_roles (этот фильтр запрещен)
8. Все временные ограничения должны быть преобразованы в соответствующие фильтры
9. Если пользователь указывает "до X часов", используй preferred_end_time
10. Если "после X часов" - preferred_start_time
11. Комбинации типа "с X до Y" - оба фильтра
12. Все временные ограничения типа "до 16" преобразуй в "preferred_end_time": "16:00"
13. Дни недели указывай в нижнем регистре (понедельник, вторник)

Доступные фильтры:
- exclude_days: ["понедельник"] - дни для исключения
- max_classes_per_day: {{"пятница": 1}} - макс. пар в день
- preferred_days: ["вторник", "четверг"] - только эти дни
- no_morning_classes: true - нет пар до 10:00
- no_evening_classes: true - нет пар после 18:00
- preferred_start_time: "10:00" - начало не раньше
- preferred_end_time: "16:00" - конец не позже
- min_break: 20 - мин. перерыв между парами (мин)
- no_gaps: true - нет окон между парами
- max_daily_teachers: 4 - макс. преподавателей в день
- preferred_teachers: ["Лавров"] - только эти преподав.
- excluded_teachers: ["Смирнов"] - исключить этих преподав.
- teacher_roles: {{"Петров": "семинары"}} - роли преподав.
- max_teacher_classes_per_day: {{"Лавров": 1}} - макс. пар/день
- no_consecutive_teacher_classes: true - не две подряд

Примеры запросов и соответствующих фильтров:
1. "Не хочу пар в понедельник" → {{"exclude_days": ["понедельник"]}}
2. "Пары только по вторникам и четвергам" → {{"preferred_days": ["вторник", "четверг"]}}
3. "Хочу, чтобы лекции вел только Лавров" → {{"preferred_teachers": ["Лавров"], "teacher_roles": {{"Лавров": "лекция"}}}}
4.  "хочу выходной в среду" → {"exclude_days": ["среда"]}
5.  "пары до 15" → {"preferred_end_time": "15:00"}
6. "не хочу пар в пятницу и после 16" → {"exclude_days": ["пятница"], "preferred_end_time": "16:00"}

Примеры временных фильтров:
1. "пары до 16" → {"preferred_end_time": "16:00"}
2. "не раньше 10 утра" → {"preferred_start_time": "10:00"}
3. "только с 10 до 15" → {"preferred_start_time": "10:00", "preferred_end_time": "15:00"}

Доступные временные фильтры:
- preferred_start_time: "HH:MM" - начало не раньше
- preferred_end_time: "HH:MM" - конец не позже
- no_morning_classes: true - нет пар до 10:00
- no_evening_classes: true - нет пар после 18:00


Пожелания пользователя: "{user_input}"
"""
 
def load_schedules():
    """Загружает расписания из JSON-файла с проверкой структуры."""
    try:
        with open(SCHEDULES_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
            # Проверка структуры (примерная)
            if not isinstance(data, list):
                raise ValueError("Файл должен содержать список расписаний")
            for schedule in data:
                if "id_расписания" not in schedule or "предметы" not in schedule:
                    raise ValueError("Неверная структура расписания")
            
            return data
    except Exception as e:
        print(f"Ошибка загрузки расписаний: {e}")
        return None
    
def save_results(data, filename):
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"Ошибка сохранения {filename}: {e}")
        return False

def generate_filters(user_input):
    headers = {
        "Authorization": f"Api-Key {YANDEX_GPT_API_KEY}",
        "Content-Type": "application/json"
    }

    # Создаем безопасный запрос
    prompt = PROMPT_TEMPLATE.replace("{user_input}", user_input.replace("{", "{{").replace("}", "}}"))
    
    data = {
        "modelUri": "gpt://b1gu5hu4elo0ishbti6b/yandexgpt-lite",
        "completionOptions": {
            "stream": False,
            "temperature": 0.3,
            "maxTokens": 1000
        },
        "messages": [{
            "role": "user",
            "text": prompt
        }]
    }

    try:
        response = requests.post(YANDEX_GPT_URL, headers=headers, json=data, timeout=15)
        response.raise_for_status()
        result = response.json()
        text = result['result']['alternatives'][0]['message']['text'].strip()
        
        # Очистка ответа
        text = text.strip('`').strip()
        if text.startswith('json'):
            text = text[4:].strip()
        
        # Парсинг JSON с обработкой ошибок
        try:
            filters = json.loads(text)
        except json.JSONDecodeError as e:
            print(f"Ошибка парсинга JSON: {e}")
            print(f"Полученный текст: {text}")
            filters = {}
        
        # Добавляем временные фильтры вручную
        if "до" in user_input:
            time_match = re.search(r"до (\d{1,2})", user_input)
            if time_match:
                hour = time_match.group(1).zfill(2)
                filters["preferred_end_time"] = f"{hour}:00"
        
        if "выходной в среду" in user_input.lower():
            filters["exclude_days"] = ["среда"]
        
        return filters if filters else None
        
    except Exception as e:
        print(f"Ошибка генерации фильтров: {e}")
        return None

def time_to_minutes(time_str):
    try:
        time_obj = datetime.strptime(time_str.split('–')[0].strip(), "%H:%M")
        return time_obj.hour * 60 + time_obj.minute
    except:
        return 0

def class_end_time(time_str):
    try:
        parts = time_str.split('–')
        if len(parts) > 1:
            time_obj = datetime.strptime(parts[1].strip(), "%H:%M")
            return time_obj.hour * 60 + time_obj.minute
        return 0
    except:
        return 0

def matches_filters(schedule, filters):
    """Проверяет, соответствует ли расписание фильтрам (адаптировано под новую структуру)."""
    if not filters or not schedule:
        return False

    day_stats = {}
    teacher_stats = {}
    
    for subject in schedule["предметы"]:
        for cls in subject["занятия"]:
            day = cls["день"].lower()
            cls_type = cls["тип_занятия"].lower()
            teachers = [t.lower() for t in cls["преподаватели"]]
            start_time = time_to_minutes(cls["время"])
            end_time = class_end_time(cls["время"])
            
            # Обновляем статистику по дням и преподавателям
            if day not in day_stats:
                day_stats[day] = {
                    'count': 0,
                    'teachers': set(),
                    'class_types': set(),
                    'classes': []
                }
            
            day_stats[day]['count'] += 1
            day_stats[day]['teachers'].update(teachers)
            day_stats[day]['class_types'].add(cls_type)
            day_stats[day]['classes'].append({
                'start': start_time,
                'end': end_time,
                'teachers': teachers,
                'type': cls_type
            })
            
            for teacher in teachers:
                if teacher not in teacher_stats:
                    teacher_stats[teacher] = {
                        'count': 0,
                        'days': set()
                    }
                teacher_stats[teacher]['count'] += 1
                teacher_stats[teacher]['days'].add(day)
    
    # Далее идёт проверка фильтров (как в оригинале, но с учётом новой структуры)
    # ... (остальная часть функции без изменений)
    # Проверка фильтров
    for day, stats in day_stats.items():
        # 1. Исключенные дни
        if 'exclude_days' in filters and day in [d.lower() for d in filters['exclude_days']]:
            return False
            
        # 2. Максимум пар в день
        if 'max_classes_per_day' in filters:
            for filter_day, max_count in filters['max_classes_per_day'].items():
                if day == filter_day.lower() and stats['count'] > max_count:
                    return False
                    
        # 3. Только определенные дни
        if 'preferred_days' in filters and day not in [d.lower() for d in filters['preferred_days']]:
            return False
            
        # 4. Утренние/вечерние пары
        if filters.get('no_morning_classes'):
            if any(cls['start'] < time_to_minutes("10:00") for cls in stats['classes']):
                return False
                
        if filters.get('no_evening_classes'):
            if any(cls['end'] > time_to_minutes("18:00") for cls in stats['classes']):
                return False
                
        # 5. Время начала/окончания
        if 'preferred_start_time' in filters:
            min_start = time_to_minutes(filters['preferred_start_time'])
            if any(cls['start'] < min_start for cls in stats['classes']):
                return False
                
        if 'preferred_end_time' in filters:
            max_end = time_to_minutes(filters['preferred_end_time'])
            if any(cls['end'] > max_end for cls in stats['classes']):
                return False
                
        # 6. Перерывы между парами
        if 'min_break' in filters:
            classes_sorted = sorted(stats['classes'], key=lambda x: x['start'])
            for i in range(1, len(classes_sorted)):
                if classes_sorted[i]['start'] - classes_sorted[i-1]['end'] < filters['min_break']:
                    return False
                    
        # 7. Нет окон между парами
        if filters.get('no_gaps'):
            classes_sorted = sorted(stats['classes'], key=lambda x: x['start'])
            for i in range(1, len(classes_sorted)):
                if classes_sorted[i]['start'] != classes_sorted[i-1]['end']:
                    return False
                    
        # 8. Максимум преподавателей в день
        if 'max_daily_teachers' in filters and len(stats['teachers']) > filters['max_daily_teachers']:
            return False
            
        # 9. Проверка преподавателей
        if 'preferred_teachers' in filters:
            preferred = [t.lower() for t in filters['preferred_teachers']]
            if not any(any(pt in teacher for teacher in stats['teachers']) for pt in preferred):
                return False
                
        if 'excluded_teachers' in filters:
            excluded = [t.lower() for t in filters['excluded_teachers']]
            if any(any(et in teacher for teacher in stats['teachers']) for et in excluded):
                return False
                
        # 10. Роли преподавателей
        if 'teacher_roles' in filters:
            for teacher, role in filters['teacher_roles'].items():
                teacher_lower = teacher.lower()
                role_lower = role.lower()
                if not any(cls['type'] == role_lower and teacher_lower in cls['teachers'] 
                          for cls in stats['classes']):
                    return False
                    
        # 11. Ограничения на преподавателей
        if 'max_teacher_classes_per_day' in filters:
            for teacher, max_count in filters['max_teacher_classes_per_day'].items():
                teacher_lower = teacher.lower()
                teacher_count = sum(1 for cls in stats['classes'] if teacher_lower in cls['teachers'])
                if teacher_count > max_count:
                    return False
                    
        if filters.get('no_consecutive_teacher_classes'):
            classes_sorted = sorted(stats['classes'], key=lambda x: x['start'])
            for i in range(1, len(classes_sorted)):
                if (classes_sorted[i]['start'] == classes_sorted[i-1]['end'] and
                    any(t in classes_sorted[i-1]['teachers'] for t in classes_sorted[i]['teachers'])):
                    return False
    
    return True

def generate_schedules_report(input_file="matched_schedules.json", output_file="schedules_report.txt"):
    """
    Генерирует удобочитаемый отчет о подходящих расписаниях в формате TXT.
    
    Args:
        input_file (str): Путь к JSON-файлу с результатами (по умолчанию matched_schedules.json)
        output_file (str): Путь к выходному TXT-файлу (по умолчанию schedules_report.txt)
    
    Returns:
        bool: True если отчет успешно создан, False при ошибке
    """
    try:
        # Загрузка данных из JSON
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        matched_schedules = data.get("matched_schedules", [])
        
        # Формирование отчета
        report_lines = ["Вам подходят следующие расписания:\n\n"]
        
        for i, schedule in enumerate(matched_schedules, 1):
            # Собираем уникальные предметы для текущего расписания
            subjects_info = []
            for subject in schedule["предметы"]:
                subject_str = f"{subject['название_предмета']} - {subject['группа']}"
                if subject_str not in subjects_info:  # Убираем дубликаты
                    subjects_info.append(subject_str)
            
            # Формируем строку для текущего расписания
            schedule_line = f"Расписание {i}: {', '.join(subjects_info)}\n"
            report_lines.append(schedule_line)
        
        # Запись в файл
        with open(output_file, 'w', encoding='utf-8') as f_out:
            f_out.writelines(report_lines)
        
        print(f"\nОтчет сохранен в файл: {output_file}")
        return True
    
    except FileNotFoundError:
        print(f"Ошибка: файл {input_file} не найден")
        return False
    except json.JSONDecodeError:
        print(f"Ошибка: файл {input_file} содержит некорректный JSON")
        return False
    except Exception as e:
        print(f"Неизвестная ошибка при создании отчета: {e}")
        return False

def main():
    user_input = input("Введите ваши пожелания к расписанию: ")
    
    filters = generate_filters(user_input)
    if not filters:
        print("Не удалось сгенерировать фильтры")
        return
        
    print("\nСгенерированные фильтры:")
    print(json.dumps(filters, indent=2, ensure_ascii=False))
    
    schedules = load_schedules()
    if not schedules:
        return
        
    matched = [s for s in schedules if matches_filters(s, filters)]
    
    if save_results({
        "filters": filters,
        "matched_schedules": matched,
        "count": len(matched)
    }, RESULTS_FILE):
        print(f"\nНайдено {len(matched)} подходящих расписаний")
        print(f"Результаты сохранены в {RESULTS_FILE}")


    generate_schedules_report()

if __name__ == "__main__":
    main()